## Question 1: According to your results (i.e., elbow_k), are there 3 species of iris represented in the iris data set?
 - Yes, according to my results we can see that there is three species of iris represnted in the data set. This is beacuse the k means clustering was able to sort all 150 pieces of data into the the three different clusters, thus we have 3 species.

## Question 2a: According to your AIC results (i.e., aic_elbow_k), are there 3 species of iris represented in the iris data set?
 - Yes, according to my results we can see that there is three species of iris represnted in the data set. This is beacuse the AIC clustering was able to sort all 150 pieces of data into the the three different clusters, thus we have 3 species.

## Question 2b: According to your BIC results (i.e., bic_elbow_k), are there 3 species of iris represented in the iris data set?
 - Yes, according to my results we can see that there is three species of iris represnted in the data set. This is beacuse the BIC clustering was able to sort all 150 pieces of data into the the three different clusters, thus we have 3 species.